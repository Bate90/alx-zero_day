# 0x02-git
  
0x002-vi Project is a vim related tasks.


### Precondition 

- Install emacs or vim
- Create [Github](https://github.com/)

