# 0x02-Vagrant
  
0x002-vagrant Project is a vim related tasks.


### Precondition 

- Install Ubuntu14
- Create [Github](https://github.com/)

