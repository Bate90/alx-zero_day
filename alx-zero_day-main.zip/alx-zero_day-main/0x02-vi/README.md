#0x02-vi

0x002-vi Project is a vim related tasks.


### Precondition 

- Install vim 
- Create [Github](https://github.com/)