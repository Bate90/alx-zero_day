# 0x01-Emacs
  
0x002-Emacs Project is a vim related tasks.


### Precondition 

- Install emacs
- Create [Github](https://github.com/)

